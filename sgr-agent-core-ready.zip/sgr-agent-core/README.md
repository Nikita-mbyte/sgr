# sgr-agent-core Helm chart

Helm chart for deploying `sgr-agent-core` in Kubernetes.

## What this chart does

- Runs one SGR agent server per Helm release
- Mounts SGR config files (`config.yaml`, `agents.yaml`, `logging_config.yaml`) from ConfigMap or Secret
- Exposes service on port `8010`
- Configures health checks against `/health`

## Quick start

```bash
helm upgrade --install sgr-hr ./charts/sgr-agent-core \
  --namespace sgr \
  --create-namespace \
  -f ./charts/sgr-agent-core/values.yaml
```

## Reuse for multiple agents

Use one chart and multiple values files:

```bash
helm upgrade --install sgr-hr ./charts/sgr-agent-core -n sgr -f values-hr.yaml
helm upgrade --install sgr-legal ./charts/sgr-agent-core -n sgr -f values-legal.yaml
```

Each release gets isolated Deployment/Service and its own config.

## Config source modes

`config.enabled: true` supports 2 modes:

- managed resource (chart creates it):
  - `config.existingName: ""`
  - `config.type: configMap` or `secret`
  - `config.files` contains YAML files
- existing resource (created outside chart):
  - `config.existingName: my-sgr-config`
  - `config.type` must match resource type (`configMap` or `secret`)

## Required image override

By default repository is placeholder. Set your real image:

```yaml
image:
  repository: nexus.isb/your-project/sgr-agent-core
  tag: "0.7.0"
```

## Notes

- If your image hardcodes ENTRYPOINT args, `container.command` in values can override it.
- Put sensitive env vars into Secret and pass through `container.envFrom`.
